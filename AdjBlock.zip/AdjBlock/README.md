# Adjara_AdBlock

აჭარანეტის რეკლამების ბლოკერი <3
მადლობა არაა საჭირო ; ))))
my fb: https://www.facebook.com/BigBangTheory2019